# Tennis Predictor — Code Review Package

No secrets, no node_modules, no build artifacts, no .git history.
All files are TypeScript source only.

---

## Folder map

### 1_scoring_grading/
Computes the core numbers shown on every parlay card:
- Validation % — overall evidence confidence
- Risk % / Upset Risk — probability the pick fails
- Removal % — probability the engine says REMOVE
- Agreement (X/7 or X/8) — how many weighted sources agree on the predicted winner
- Closeness — how lopsided the matchup is (low = clear favourite, high = coin-flip)
- Grade A / B / C — data-depth grade based on match-history sample size

Key files:
- builderScoringService.ts — orchestrates the full parlay card score; owns Validation/Risk/Removal/Closeness
- recommendation.ts        — KEEP / BORDERLINE / REMOVE decision + Grade assignment
- disagreement.ts          — Agreement X/N calculation, weighted source voting
- ensemble.ts              — raw probability ensemble (votes from all sub-modules)
- dataQuality.ts           — Data Quality % and grade label (Excellent / Good / Sparse)
- upsetRisk.ts             — Upset Risk score and tier (Low / Medium / High)
- finalConsistencyCheck.ts — post-scoring guard that can override a KEEP to BORDERLINE
- types.ts                 — shared engine types

---

### 2_market_odds/
Fetches live bookmaker odds and uses them as one voting source.

Key files:
- index.ts               — provider orchestration; how odds are combined across sources
- oddsApiIoProvider.ts   — Odds-API.io integration (provider 1)
- theOddsApiProvider.ts  — The Odds API integration (provider 2)
- impliedProbability.ts  — converts American / decimal odds to implied probability
- nameMatch.ts           — fuzzy player name matching between our DB and bookmaker feed
- types.ts               — MarketOdds, EdgeSummary, provider types
- builderProviderFetch.ts — how the parlay builder fetches odds alongside match history
- adminParlay.ts          — admin route that can trigger a re-score / odds refresh

NOTE: Market odds are fetched fresh on every prediction call. There is no separate
scheduled re-fetch — the odds are live whenever the user refreshes the card.

---

### 3_match_status/
Checks whether a player has already played today or a match is live.

Key files:
- playerProfileWarnings.ts — generates the "X may have played today" warning using
                              the live fixtures window; NOT a hard match-status API call
- availability.ts           — player availability gate (checks injury/withdrawal flags)
- fixtures.ts               — live fixtures route (serves upcoming/live match data)
- upcomingWindow.ts         — computes the upcoming match window used for scheduling checks

IMPORTANT: There is NO direct match_status = 'in_progress' / 'completed' check.
The "may have played today" flag is inferred: if a player appears in today's fixture
window AND their scheduled time has passed, the warning fires. There is no real-time
score feed that updates the pick once a match starts.

---

### 4_elite_tier/
Defines what qualifies a pick as "Elite" vs standard.

Key files:
- eliteTier.ts         — Elite gate logic: all 4 criteria must pass simultaneously
                          (data quality threshold + 4 specific sub-modules all agree
                           + specialist validator present + calibrated probability agrees)
- eliteTierBacktest.ts — historical backtest of Elite-tier accuracy (logged separately
                          from main walk-forward)

Note: recommendation.ts (in folder 1) assigns Grade A/B/C based on match-history
depth, while eliteTier.ts assigns the Elite badge based on evidence quality.
These are independent axes.

---

### 5_db_schema/
Defines how predictions are stored and whether they are immutable.

Key files:
- predictions.ts    — main predictions table schema (Drizzle ORM)
- evaluation.ts     — evaluation_predictions table: stores graded outcomes
                       IMMUTABLE once settled — a DB trigger enforces settle-once.
                       calibratedProbability and foldId are the only exempt fields.
- savedCards.ts     — user-saved parlay cards schema
- savePrediction.ts — service layer that writes a prediction to the DB
- settle.ts         — outcome settlement logic; writes the actual result (win/loss)

Immutability summary:
- Live predictions (predictions table): can be re-scored/overwritten on refresh
- Graded predictions (evaluation_predictions): IMMUTABLE after settlement.
  The DB trigger prevents any update to outcome fields once set.

---

### 6_accuracy_backtest/
Historical scoring, walk-forward evaluation, and the accuracy dashboard.

Key files:
- metrics.ts          — accuracy metrics computation (log loss, Brier, calibration)
- backtestService.ts  — backtest runner that scores historical predictions
- walkForward.ts      — walk-forward evaluation (rolling train/test folds)
- historicalScoring.ts — scores historical matches against the engine
- calibration.ts      — isotonic regression / Platt scaling calibration model
- evaluation.ts       — API route for the accuracy/evaluation dashboard endpoints
- backtests.ts        — API route for backtest job triggering and results

---

## What is NOT in this package

- node_modules, dist, .next, .git
- .env files, API keys, secrets
- Player data fetch providers (RapidAPI, API-Tennis, MatchStat, Sofascore, BSD)
- Authentication / payments code
- Screenshot OCR / import pipeline
- Frontend (Tennis Predictor UI)
- Test files (*.test.ts)
